#!/usr/bin/env python
# Copyright (C) 2013 Ivan Leichtling.

from setuptools import setup

setup(
    name = 'airodump-iv',
    version = '0.2',
    author = 'Ivan Leichtling',
    packages = ['airodump_iv', 'airodump_iv.lib'],
    install_requires = ['scapy'],
    include_package_data = True,
    url = 'https://github.com/ivanlei/airodump-iv',
    license ='GNU General Public License v3 or later (GPLv3+)',
    keywords = 'airodump-ng airodump-iv python scapy',
    description='A python implementation of airodump-ng - the classic wifi sniffing tool.'
)
